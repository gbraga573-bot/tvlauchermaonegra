package com.meulauncher.tv;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return abrirLink(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return abrirLink(request.getUrl().toString());
            }
        });

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();
    }

    /** Trata os links "intent:" do HTML abrindo o app ou a configuracao certa. */
    private boolean abrirLink(String url) {
        if (url == null || !url.startsWith("intent:")) {
            return false; // links normais/arquivos carregam dentro do launcher
        }
        try {
            Intent parsed = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            String pkg = parsed.getPackage();
            Intent launch;

            if (pkg != null && parsed.getComponent() == null && parsed.getData() == null
                    && (parsed.getAction() == null || Intent.ACTION_VIEW.equals(parsed.getAction()))) {
                // Link do tipo "abrir app pelo pacote"
                PackageManager pm = getPackageManager();
                launch = pm.getLeanbackLaunchIntentForPackage(pkg);
                if (launch == null) launch = pm.getLaunchIntentForPackage(pkg);
                if (launch == null) {
                    Toast.makeText(this, "App nao instalado. Abrindo a Play Store...", Toast.LENGTH_SHORT).show();
                    launch = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
                }
            } else {
                // Links de configuracoes (Wi-Fi, Configuracoes, Busca)
                launch = parsed;
                launch.setSelector(null);
            }

            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "Nao foi possivel abrir", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        // Tela inicial: o botao Voltar nao fecha o launcher
        if (web != null && web.canGoBack()) web.goBack();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.requestFocus();
        }
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }
}
